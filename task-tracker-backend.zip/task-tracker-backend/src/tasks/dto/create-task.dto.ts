export class CreateTaskDto {
    readonly title: string;
    readonly description: string;
    userId: string;
  }
  